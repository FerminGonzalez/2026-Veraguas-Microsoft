import type { Environment } from './environment';

export const environment: Environment = {
  production: true,
  apiBaseUrl: 'https://hackathon-copa-2026-team-13-api.azurewebsites.net',
  services: {
    INFORMATION_ENDPOINT_URL: '/api/information',
    SERVICE_ENDPOINT_URL: '/api/services'
  }
};
